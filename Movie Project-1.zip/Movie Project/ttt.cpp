#include<stdio.h>
 int main()
  {
   for (int i=1; i<=1&i<=5;i++)
    {
	 for (int j=1;j<=3;j++)
	  {
	   printf("*");
	    }
		 printf("\n");
		  }
	}
