#include<stdio.h>
#include<conio.h>
main()
{
    int i,n,r,s=0;
    
     
    printf("\n  Enter The Number:");
    scanf("%d",&n);
     
    //LOOP FOR FINDING THE REVERSE OF A NUMBER

