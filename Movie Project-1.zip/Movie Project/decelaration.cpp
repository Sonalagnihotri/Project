int changeprize(int);
void reservation(int *,int,int );
int choice1(void);
void cancel(int *);
void records(int);         
void ticket1(int choice,char name[10],int id2);
void ticket2(int choice,char name[10],int id2);
void ticket3(int choice,char name[10],int id2);
int cmovie(void);

